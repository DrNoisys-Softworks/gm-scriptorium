# gm-apprentice-publish

Static site generator for [gm-apprentice](https://github.com/AntTheLimey/gm-apprentice)
campaign vaults. Reads structured markdown files produced by the
campaign-organizer skill and outputs a self-contained HTML site suitable
for GitHub Pages or Cloudflare Pages.

## Requirements

Node 22 or later. Check with `node --version`.

## Vendored dependencies

This tool's runtime dependencies (`gray-matter`, `lunr`,
`markdown-it`, and their transitive deps) are **committed** under
`node_modules/` — an exception to the usual rule, enforced by a
negation at the bottom of the repo's root `.gitignore`.

This is deliberate. The gm-apprentice plugin distributes this tool
by **git-copying** the repo into the plugin cache
(`~/.claude/plugins/cache/gm-apprentice/.../tools/publish`). A
campaign site then pins it with a `file:` dependency, which npm
satisfies by **symlinking** the cache directory into the site's
`node_modules`. At build time Node resolves the symlink to its real
location and looks for the tool's own dependencies *there*, in the
cache — not in the site. Since `npm install` is never run against
the cached copy, the only reliable way for the dependencies to be
present is for them to travel with the git copy. Vendoring them
makes a fresh install build with zero extra steps, offline.

The alternative — having the consuming site install the deps — does
not work: Node resolves the symlinked tool from the cache path, so
the site's `node_modules` is never consulted (confirmed empirically,
including with `--preserve-symlinks`).

**Re-vendoring after a dependency change:** edit `package.json` /
`package-lock.json`, then:

```bash
cd tools/publish
rm -rf node_modules && npm ci --omit=dev
rm -rf node_modules/.bin node_modules/.package-lock.json
git add node_modules
```

The `runtime-deps` test fails if a declared dependency is not both
requireable and git-tracked, and the `clean-install` integration
test fails if a clean git-copy + symlinked site cannot build.

## Installation

**This tool ships inside the [gm-apprentice](https://github.com/AntTheLimey/gm-apprentice)
plugin and is not installed from the npm registry.** When you install the
plugin, the tool lands in the plugin cache, and the `publish-site` skill
drives it from there — the skill scaffolds a site whose `package.json`
pins the tool with a `file:` path into that cache, so every build uses the
exact version that matches your installed plugin. There is nothing to
`npm install` globally.

> The `gm-apprentice-publish` package on npm is **deprecated**. It stopped
> at 1.2.1, and that version leaks GM-only content onto the player site.
> Don't install it. To run the in-cache copy directly without the skill:
>
> ```bash
> node "<plugin-cache>/gm-apprentice/<version>/tools/publish/bin/gm-publish.js" <command>
> ```

## Releases and pinning from outside the plugin

Every version of this tool is tagged `publish-v<version>` (the version in
`package.json`, for example `publish-v1.11.40`) with a release that carries:

- `gm-apprentice-publish-<version>.tgz`, the `npm pack` output. The
  vendored runtime dependencies are bundled inside it
  (`bundleDependencies`), so it installs and builds with no registry
  access.
- `SHA256SUMS`, the checksum of that tarball.
- Notes listing only the `tools/publish` changes since the previous
  `publish-v*` tag.

These releases are never marked latest; the plugin's `v*` release stays the
repo's latest. A `publish-v*` tag is created once and never moved.
The workflow is `.github/workflows/publish-tool-release.yml`. It runs when
`tools/publish/package.json` changes on `main`, runs this tool's tests,
then packs, tags and releases.

A project outside the plugin (a site with no plugin cache) pins like this:

```bash
gm-apprentice-publish update-pin --site <site-dir> --tag publish-v1.11.40
```

That downloads the `.tgz` and `SHA256SUMS` from the release, verifies the
checksum (a mismatch aborts before anything is written), keeps the tarball
in `<site-dir>/vendor/`, points the site's `gm-apprentice-publish`
dependency at it (`file:vendor/gm-apprentice-publish-1.11.40.tgz`) and runs
`npm install`. `--check` reports whether the site is on that tag without
touching the network. To do it by hand, download both files from
`https://github.com/AntTheLimey/gm-apprentice/releases/tag/publish-v1.11.40`, run
`sha256sum -c SHA256SUMS` (`shasum -a 256 -c SHA256SUMS` on macOS), and use
the `.tgz` as a `file:` dependency. To see what a repin brings, diff tag to
tag: `git log publish-vOLD..publish-vNEW -- tools/publish`.

### Backfilling older tags (maintainer)

Run by the repo owner after the release workflow has merged; CI never
does. Each command creates a local annotated tag at the commit whose
`package.json` carries that version, and prints the push command. The
script refuses a wrong version or an existing tag.

```bash
scripts/backfill-publish-tag.sh 1.11.30 5779522
scripts/backfill-publish-tag.sh 1.11.39 95bdd0cf
git push origin refs/tags/publish-v1.11.30 refs/tags/publish-v1.11.39
```

Backfilled tags exist for tag-to-tag diffs only. They have no release or
tarball, so `update-pin --tag` works from `publish-v1.11.40` onwards.

## Quick start

**1. Scaffold a new site repo** (run the tool from the plugin cache; the
scaffold auto-pins itself to that version)

```bash
TOOL="<plugin-cache>/gm-apprentice/<version>/tools/publish/bin/gm-publish.js"
node "$TOOL" init my-campaign-site
cd my-campaign-site
```

This creates:

```text
my-campaign-site/
  package.json
  vault.config.json   ← edit this
  README.md
  css/overrides.css
  .gitignore
  .nojekyll
```

**2. Configure `vault.config.json`**

Open `vault.config.json` and set `vaultPath` to the absolute or relative
path of your gm-apprentice vault, and `siteUrl` to the GitHub Pages URL
you plan to publish to (e.g. `https://username.github.io/campaign-name`).

**3. Build** (the scaffold pinned the tool, so npm resolves it locally)

```bash
npm install   # links the pinned tool from the plugin cache (deps vendored)
npm run build
```

Output is written to the `docs/` folder. Push to GitHub and enable
GitHub Pages from the `docs/` folder in your repo settings.

---

## CLI reference

```text
gm-apprentice-publish init [dir]          Scaffold a new site
gm-apprentice-publish build [options]     Build the site from vault
gm-apprentice-publish --version           Print version
gm-apprentice-publish --help              Print help
```

### `init [dir]`

Scaffolds a new site in `dir` (defaults to the current directory).
Refuses to overwrite existing files — run it in an empty directory
or provide a new directory name.

`init` also writes `publish.site: true` and `publish.site_dir`, the
absolute path of the new site folder, into the vault's
`_meta/vault-config.md`. `update-pin` adds either to a vault that lacks
it and leaves a `site: false` alone. `publish.site` says whether the
vault has a site: with it set to `false`, `build` and `deploy` stop
with one line and exit code 1, and nothing is built.

### `build [--config path]`

Reads `vault.config.json` (or the file at `--config path`) and writes
the generated site into the `outputDir` specified in that config.
Cleans the output directory before each build, preserving any
directories listed in `preserveDirs`.

| Option | Default | Description |
|--------|---------|-------------|
| `--config <path>` | `./vault.config.json` | Path to config file |

### `lines`

Answers what the build would publish, for text handed in on stdin.
`vault_check.py` uses it, so the vault checks never keep their own copy
of the build's filters. It takes no arguments: one
JSON request per input line, one JSON answer per output line, until
stdin closes.

| Request | Answer |
|---------|--------|
| `{"op":"published","text":…,"excludeSections":[…],"publish":"all"}` | `{"text":…}`: the body the site renders. `publish` is `all`, `stub` (with `include`, the page's `publish_include_sections`) or `none`. |
| `{"op":"sections","text":…,"excludeSections":[…]}` | `{"withheldBy":[…]}`: for each line of `text`, the excluded section withholding it, or `null`. |
| `{"op":"stub","text":…,"include":[…]}` | `{"kept":[…]}`: for each line of `text`, whether a stub page keeps it. |
| `{"op":"site","vault":…}` | `{"publishes":…,"site":…,"siteDir":…}`: whether the vault's `_meta/vault-config.md` has a `publish:` block, whether its site is on (`publish.site`; unset, a `site_dir` says on), and the absolute path its `site_dir` names (`null` when the site is off or no folder is named). |

A request that cannot be answered gets `{"error":…}` and the process
carries on. That includes a malformed one: `text` must be a string, and
`excludeSections` (and `include`, where it applies) must be present and
a list of strings.

---

## vault.config.json reference

| Field | Type | Description |
|-------|------|-------------|
| `siteTitle` | string | Site name shown in the nav bar and page title |
| `host` | string | Deploy target: `github-pages` (default/absent) or `cloudflare-pages`. Affects only the deploy step, not the built output. |
| `siteUrl` | string | Canonical base URL. For `cloudflare-pages` set it to the `.pages.dev` (or custom) URL — Cloudflare serves at the root, so a `github.io` URL breaks the 404 page (the build warns). |
| `cloudflarePagesProject` | string | Optional. Cloudflare Pages project name; defaults to the site directory name. |
| `landingTagline` | string | One-sentence campaign hook shown on the landing page hero |
| `vaultPath` | string | Path to the vault directory (resolved relative to the config file) |
| `outputDir` | string | Directory to write generated HTML into (resolved relative to the config file) |
| `attachmentsDir` | string | Subfolder inside `vaultPath` that holds images (default `_attachments`) |
| `folderMap` | object | Maps vault folder paths to site output paths (see below) |
| `excludeDirs` | array | Vault subdirectories to skip entirely (e.g. `["_meta", "_Templates"]`). Unioned with `publish.exclude_dirs` from `_meta/vault-config.md` — either source can add to the skip list, neither shadows the other. Entries are normalized (a trailing slash, a leading `./`, backslashes, and an absolute path inside the vault are all rewritten to the same vault-relative spelling the scanner uses) and matched case-insensitively, so `"NPCs/Hidden/"`, `"./NPCs/Hidden"` and `"npcs/hidden"` all exclude the same folder. |
| `excludeSections` | array | Section headings to strip before rendering, at any heading level (e.g. `["GM Notes"]`) |
| `preserveDirs` | array | Output subdirectories to keep across builds (e.g. `["superpowers"]`) |

### folderMap

`folderMap` controls which vault folders become pages and where they
appear in the output. Keys are paths relative to `vaultPath`; values
are paths relative to `outputDir`.

```json
{
  "folderMap": {
    "Characters/NPCs": "characters/npcs",
    "Locations": "locations",
    "Factions & Organizations": "factions"
  }
}
```

Files in unmapped folders are silently skipped. Files without a
`type` frontmatter field are also skipped regardless of folder.

### Default folderMap

The scaffold template provides this default, matching the standard
campaign-organizer vault structure:

```json
{
  "Characters/PCs": "characters/pcs",
  "Characters/NPCs": "characters/npcs",
  "Locations": "locations",
  "Factions & Organizations": "factions",
  "Items & Artifacts": "items",
  "Creatures": "creatures",
  "Events": "events",
  "Documents": "documents",
  "Clues": "clues",
  "_Campaign": "campaign"
}
```

---

## Page templates

The `type` frontmatter field determines which template renders each page.

| type value | Template | Notes |
|------------|----------|-------|
| `pc` | Player character | Accordion sections from H2 headings |
| `npc` | Non-player character | Header card + body content |
| `location` | Location | Header card with parent breadcrumb |
| `creature` | Creature | Combat stat block + body |
| `item` | Item | Stat block + body |
| `faction` / `organization` | Faction | Goals, leadership, auto-generated member list |
| `event`, `clue`, `document`, `chapter`, `scene` | Smart wiki | Frontmatter badges + body |
| `session` | Smart wiki | Frontmatter badges + body; once the session's Wrap-Up publishes, the body is withheld everywhere and replaced by the chapter, in-game date and the opening of the Wrap-Up's recap, linked to it |
| anything else | Smart wiki | All frontmatter shown as badges |

Pages with `canon_status: SUPERSEDED` resolve wiki-links to the
superseding entity and show a `Superseded` badge. The legacy field
names `source_confidence` and `confidence` are still honored at read
time for vaults that haven't run the 1.8.0 migration.

### Landing page (dashboard)

The root `index.html` is a campaign dashboard generated from vault data.
It includes these sections (each omitted if no relevant data exists):

- **Hero** — campaign image (from `publish.theme.campaign_image` in
  `vault-config.md`), site title, last-played date, and in-game date
  (from `setting_year` in vault-config.md)
- **Story So Far** — first paragraph of the most recent played session's
  `## Narrative Recap` section, with a link to the full session page
- **The Team** — PC cards with portrait (or initials fallback), status
  badge (Active / KIA / MIA), and `key_traits` or `occupation`
- **Key NPCs** — up to 8 NPCs scored by session mentions, relationship
  count, and tag signals, with inferred role labels (Patron, Antagonist,
  Companion, etc.)
- **Explore** — compact grid of category index pages with entry counts,
  excluding PC and NPC categories (those have dedicated sections above)

### Section index banners

Put a hero image or a clickable map at the top of a section index. Either
drop a `_banner.*` file in the section's vault folder
(`Locations/_banner.svg`), or name one explicitly:

```yaml
publish:
  banners:
    locations:
      image: _attachments/sector-map.webp
      link: _attachments/sector-map.svg    # optional, click-through target
      alt: Sector 7-G star chart
    factions: _attachments/factions-hero.svg   # shorthand: image only
```

Keys are output directories (`locations`, `factions`, `items`, …), not
vault folders. Config wins over the conventional file. Accepted
extensions, in preference order: `svg`, `webp`, `avif`, `png`, `jpg`,
`jpeg`, `gif`.

**SVG with no `link` is inlined**, so its internal `<a>` elements stay
clickable — a star map whose nodes link to entity pages keeps working.
An `<img>` would not run those links, and wrapping the SVG in an outer
anchor would swallow them, so anything with a `link` renders as an
`<img>` inside an `<a>` instead. That's the "raster on the page,
full-size SVG behind it" shape.

Because an inlined SVG lands in `<section>/index.html`, its internal
hrefs must be written relative to that page (`corwin-system.html`, or
`../characters/npcs/rook.html`).

Assets are copied to `docs/images/banners/<section>/`, namespaced by
section so the conventional `_banner.*` sitting in two different folders
can't collide. A banner path that resolves outside the vault, or names a
file that doesn't exist, prints a warning and is skipped rather than
failing the build. Banners apply to generated index pages; a section with
an authored `index.md` renders that page instead.

### Locations index grouping

When a campaign's geography funnels through one political root
(`Republic → Sector → System → planet`), the default Locations listing is
a single deep tree. Pivot grouping gives each mid-level node its own
section:

```yaml
publish:
  locations:
    group_by: system                    # matched against location_type
    ungrouped_label: Deep Space & Routes
```

`group_by` is a case-insensitive substring of `location_type`, so
`system` matches `star system` too. The `scifi` genre defaults it to
`system`; other genres leave grouping off, and `group_by: false` turns a
genre default back off.

Every location stays a first-class row with its own thumbnail and type
badge, with children nested beneath it. Only the scaffolding *above* the
pivot is collapsed, into a context caption. Locations with no matching
ancestor collect under `ungrouped_label`. Fewer than two matches falls
back to the flat view — one section is not a grouping.

### Player-mode image filtering

When building in `player` mode, only images referenced by the published
pages are copied to the output — with or without a publish manifest.
This prevents GM-only images (maps, handouts, portraits of hidden NPCs)
from leaking into the public site. In full mode, all vault images are
copied.

`scanAttachments` also honours `excludeDirs`/`publish.exclude_dirs`, so
a vault-relative folder listed there (including a subfolder of the
attachments tree, e.g. `_attachments/gm-maps`) never reaches the scan at
all, in either mode.

### Theme fonts

`publish.theme.fonts.heading`/`.body` name Google Fonts families by
default, and the build emits a `fonts.googleapis.com` `@import` at the
top of `css/theme.css` — every visitor's browser then requests the font
directly from Google, and the build prints a warning saying so. Two ways
to opt out:

**`source: self-host`** (the setting new vaults get) downloads each
non-generic heading/body family from Google Fonts at build time, once,
and serves it from your site. Regular and bold, roman and italic are
fetched, with Google's `unicode-range` subsets kept, and the files are
served unmodified (they are OFL-licensed). They are cached in the vault
at `_meta/font-cache/<family>/` (`_meta/` is never published), so later
builds work offline and produce the same site. If a font is not cached
and the download fails, the build warns and the family falls back to
its CSS stack; it never falls back to a Google import. Existing vaults
keep `source: google` until you change it. The scifi preset's Rajdhani
is self-hosted too.

```yaml
publish:
  theme:
    fonts:
      heading: IM Fell English
      body: Cormorant Garamond
      source: self-host    # 'google' (code default) | 'self-host' | 'local'
```

**`source: local`** self-hosts font files you supply:

```yaml
publish:
  theme:
    fonts:
      heading: Cinzel
      body: Inter
      source: local
      files:
        - family: Cinzel
          path: _attachments/fonts/Cinzel-Regular.woff2
        - family: Inter
          path: _attachments/fonts/Inter-Regular.woff2
          weight: 400       # optional, default 400
          style: normal     # optional, default normal
```

Each `files` entry is copied from the vault (path resolved relative to
`vaultPath`, same safety rule as `campaign_image`) into the site's
`fonts/` directory — under its **full relative path**, not just its
filename, so `_attachments/fonts/Cinzel-Regular.woff2` lands at
`fonts/_attachments/fonts/Cinzel-Regular.woff2`. This is deliberate:
two font files that happen to share a filename in different subfolders
(`fonts/Cinzel/Regular.woff2` and `fonts/Inter/Regular.woff2`) must not
overwrite each other. `theme.css` gets an `@font-face` rule per entry,
referencing that same path, instead of the Google import. `path` must
end in `.woff2`, `.woff`, `.ttf` or `.otf` — anything else (a mistyped
path pointing at a GM's own note, say) is rejected with a warning and
never copied. `source: local` with no `files` emits no import at all —
fonts fall back to whatever stack `cssFontValue` supplies
(`'<family>', serif`/`sans-serif`), so pair it with a generic
`heading`/`body` (`system-ui`, `serif`, …) if you don't intend to ship
font files.

A genre preset's own CSS can also hardcode a Google Fonts import
independent of `theme.fonts` — the `scifi` preset's Rajdhani heading
font is one (`css/themes/scifi.css`). `source: local` strips that
import from the copied preset CSS too, so nothing in the built output
ever requests fonts.googleapis.com or fonts.gstatic.com. Without a
`files` entry supplying Rajdhani yourself, the scifi preset's heading
font falls back to the next family in its own stack (a condensed
system font, then `sans-serif`) rather than rendering as Rajdhani.

### Image optimization

Off by default: images are copied byte-for-byte. Turn it on in
`_meta/vault-config.md` and PNG/JPEG attachments are re-encoded to WebP
as they are copied, with the `<img src>` written to match:

```yaml
publish:
  images:
    optimize: true    # default false
    format: webp      # the only supported target today
    max_width: 1600   # 0 disables resizing
    quality: 82
```

On a portrait-heavy campaign this is the single biggest weight on the
published site — one real vault of 89 portraits went from 164 MB to
11 MB.

Requires the **`cwebp`** binary on `PATH` (`brew install webp`,
`apt install webp`). If it isn't found the build prints a warning and
copies the originals unchanged, so a missing encoder never breaks a
build. Images that would grow when re-encoded keep their original bytes,
and SVG, GIF, WebP and AVIF are always passed through untouched.

Because the tool owns both the image copy and every `<img src>`, it
converts and re-references in one pass. An external postbuild that
rewrites `src` attributes after the fact has to string-match paths the
tool URL-encodes (`images/Rock%20Lavey.jpg`), and silently misses every
filename containing a space.

---

## Library API

Install as a dependency and import the functions directly:

```js
const {
  build,
  scanVault,
  buildLinkMap,
  scanAttachments,
  slugify,
  mapFolder,
  processContent,
  extractSections,
  resolveWikiLinks,
  filterSections,
  stripDataview,
  stripLeadingH1,
  renderRelationships,
  relativePath,
  escapeHtml,
  resolveImageEmbeds,
  templates,
} = require('gm-apprentice-publish');
```

### High-level

**`build(options?)`**

Runs the full build pipeline. `options.configPath` sets the config file
path (default `./vault.config.json`). Logs progress to stdout. Throws on
config parse errors; logs per-page render errors and continues.

### Scanner

**`scanVault(config)`**

Walks the vault, parses frontmatter, and returns an array of page
objects. Skips files with no `type` field and files in unmapped or
excluded folders.

**`buildLinkMap(pages)`**

Returns a `{ title: outputPath }` map used to resolve `[[wiki-links]]`.
Handles aliases and SUPERSEDED redirects.

**`scanAttachments(config)`**

Returns a `{ filename: { sourcePath, relPath } }` map of all images in
`attachmentsDir`.

**`slugify(name)`**

Converts a filename into a URL-safe slug. Strips apostrophes, replaces
`&` with `and`, collapses non-alphanumeric runs to `-`.

**`mapFolder(vaultRelPath, folderMap)`**

Returns the output directory for a given vault-relative path, or `null`
if unmapped.

### Processor

**`processContent(page, linkMap, excludeSections?, imageMap?, options?)`**

Returns `{ html, relationships, warnings }` for the page body. Resolves
wiki-links, embeds images, strips excluded sections and GM-only markers,
and runs the markdown-it renderer. Pass `options.usedImages` (a `Set`) to
track which image basenames were referenced during rendering.

**`extractSections(markdown)`**

Returns an array of `{ title, id, html }` objects split on H2 headings.
Used by the PC template for accordion panels.

**`resolveWikiLinks(markdown, linkMap, currentOutputPath)`**

Replaces `[[wiki-link]]` and `[[wiki-link|alias]]` with relative HTML
anchors computed from `currentOutputPath`.

**`filterSections(markdown, excludeHeadings)`**

Removes each section whose heading appears in `excludeHeadings`, at any
level, down to the next heading of that level or shallower. It reads
headings two ways, the renderer's parser and a plain `#` pattern at the
margin, and takes whichever withholds more: a section starts at a
heading either one sees (underlined, indented, inside a blockquote or
list) and ends only at one both see, so a `#` line in a code block or a
line with `---` under it does not end it. With the PC keep-list in
force (character sheets off) the exclude list is applied the same way
first.

**`stripDataview(markdown)`**

Removes Obsidian Dataview code blocks.

**`stripGmOnly(markdown)`**

Strips content between `<!-- gm-only -->` / `<!-- /gm-only -->` markers.
Returns the cleaned string, or `{ text, warnings }` if an unclosed
marker is detected.

**`stripLeadingH1(markdown)`**

Removes the first H1 heading from body content (the page title is
rendered separately by the template).

**`renderRelationships(frontmatter, linkMap, currentOutputPath)`**

Renders the `relationships` frontmatter array as an HTML list with
linked entity names.

**`resolveImageEmbeds(markdown, imageMap, currentOutputPath, usedImages?)`**

Replaces Obsidian `![[image.jpg]]` embeds with standard HTML `<img>` tags.
If `usedImages` (a `Set`) is provided, each resolved image basename is
added to it.

**`filterFields(frontmatter, excludeFields, overrides?)`**

Returns a shallow copy of `frontmatter` with `excludeFields` removed.
Per-entity `overrides.include` can re-include specific fields.

### Templates

**`templates`**

An object exposing `pcTemplate`, `npcTemplate`, `creatureTemplate`,
`locationTemplate`, `itemTemplate`, `factionTemplate`, `wikiTemplate`,
`indexTemplate`, `landingTemplate`, `fourOhFourTemplate`, and `generateNav`.
Template signatures vary slightly — most accept
`(page, processed, navFor, config, imageMap)`, but `pcTemplate` adds a
`sections` param, `itemTemplate`/`factionTemplate` add `linkMap` for
relationship resolution, and `landingTemplate` accepts
`(pages, navFor, config, publishConfig)`. See `lib/build.js` for exact usage.

---

## Guided setup

For a step-by-step walkthrough aimed at non-technical users, use the
`publish-site` skill in [gm-apprentice](https://github.com/AntTheLimey/gm-apprentice).
It handles GitHub Pages setup, troubleshooting, and schema migrations.

---

## License

MIT
