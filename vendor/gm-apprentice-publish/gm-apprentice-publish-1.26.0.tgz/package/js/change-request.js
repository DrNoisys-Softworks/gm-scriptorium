/* Change-request widget. Prepended to PC sheet pages via #cr-root. Submits
   natural-language sheet-edit requests to the Pages Function (Part 1), remembers
   the session code for 72h, and auto-refreshes when the player's change goes live.
   When #cr-root carries data-sheets="off" there is no sheet to change: the same
   widget is only a question channel (question copy, no page refresh on a reply).
   Pure helpers are exported for node tests; the DOM bootstrap only runs in a browser. */
(function () {
  var CODE_TTL_MS = 72 * 3600 * 1000;
  var POLL_MS = 15000;
  var ENDPOINT = '/api/request';
  var LOG_MAX = 50;
  var K_CODE = 'cr:code', K_PENDING = 'cr:pending', K_LIVE = 'cr:live', K_LOG = 'cr:log';

  function shouldPromptForCode(stored, nowMs) {
    if (!stored || typeof stored.at !== 'number' || !stored.code) return true;
    return (nowMs - stored.at) >= CODE_TTL_MS;
  }

  function resolvedResults(results, pendingIds) {
    var out = [];
    (pendingIds || []).forEach(function (id) {
      var r = (results || {})[id];
      if (r && r.response != null) out.push({ id: id, response: r.response, kind: r.kind });
    });
    return out;
  }

  function staleIds(results, pendingIds) {
    var out = [];
    (pendingIds || []).forEach(function (id) {
      var r = (results || {})[id];
      if (r && r.status === 'handled' && r.response == null) out.push(id);
    });
    return out;
  }

  // The server no longer has this request at all — it expired (or was never
  // stored). Distinct from "handled": the player must be TOLD, not silently
  // dropped, because any reply the GM wrote is lost with it (#176).
  var GONE_TEXT = 'This request expired before a reply reached you — please send it again.';
  function goneIds(results, pendingIds) {
    var out = [];
    (pendingIds || []).forEach(function (id) {
      var r = (results || {})[id];
      if (r && r.status === 'gone') out.push(id);
    });
    return out;
  }

  function needsReload(resolvedList) {
    return (resolvedList || []).some(function (x) { return x.kind === 'applied'; });
  }

  function appendLog(log, entry) {
    var next = (log || []).concat([entry]);
    return next.length > LOG_MAX ? next.slice(next.length - LOG_MAX) : next;
  }

  function setLogReply(log, id, reply, kind) {
    return (log || []).map(function (e) {
      return e.id === id ? Object.assign({}, e, { reply: reply, kind: kind }) : e;
    });
  }

  // A reply the player has not yet opened the History modal on. Entries predating
  // this feature have no `read` flag, so they read as unread — deliberately, since
  // the bug this fixes is replies the player never saw.
  function unreadCount(log) {
    return (log || []).filter(function (e) { return e.reply != null && !e.read; }).length;
  }

  function markAllRead(log) {
    return (log || []).map(function (e) {
      return e.reply != null && !e.read ? Object.assign({}, e, { read: true }) : e;
    });
  }

  function classifySubmitError(httpStatus) {
    if (httpStatus === 403) return 'code';
    if (httpStatus === 429) return 'rate';
    return 'bad';
  }

  // User-visible copy. With sheets off (#cr-root data-sheets="off") the widget is
  // only a question channel, so nothing may mention a sheet or a change.
  var COPY_DEFAULT = {
    toggle: '✎ Request a change / ask a question',
    hint: 'Type a change ("spend 1 xp to raise Streetwise") or a question ("is it worth raising DX?"). Can\'t afford something but the GM okayed it? Add "GM said OK" and it\'ll go through anyway.',
    placeholder: 'Type your change or question…',
    empty: 'Type your request first.',
    received: 'Request received.',
    live: '✓ your change is live',
  };
  var COPY_QUESTION = {
    toggle: 'Ask the GM',
    hint: 'Ask the GM a question and the reply will show up here and in your History.',
    placeholder: 'Your question for the GM',
    empty: 'Type your question first.',
    received: 'Question received.',
    live: '✓ the GM has replied',
  };
  function copyFor(sheetsOff) { return sheetsOff ? COPY_QUESTION : COPY_DEFAULT; }

  function widgetHtml(copy) {
    return '<div class="cr-bar">' +
        '<div class="cr-barhead">' +
          '<button type="button" class="cr-toggle" aria-expanded="false">' + copy.toggle + '</button>' +
          '<button type="button" class="cr-log-btn" aria-expanded="false" aria-label="Open chat history">💬 History</button>' +
        '</div>' +
        '<div class="cr-panel" hidden>' +
          '<p class="cr-hint">' + copy.hint + '</p>' +
          '<input type="text" class="cr-code" maxlength="4" placeholder="4-char code" aria-label="Session code" hidden>' +
          '<textarea class="cr-text" rows="5" aria-label="Your message" placeholder="' + copy.placeholder + '"></textarea>' +
          '<button type="button" class="cr-send">Send</button>' +
          '<span class="cr-msg" role="status"></span>' +
        '</div>' +
      '</div>';
  }

  // ---- exports for node tests (no-op in browser) ----
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      CODE_TTL_MS: CODE_TTL_MS,
      LOG_MAX: LOG_MAX,
      shouldPromptForCode: shouldPromptForCode,
      resolvedResults: resolvedResults,
      staleIds: staleIds,
      goneIds: goneIds,
      GONE_TEXT: GONE_TEXT,
      needsReload: needsReload,
      appendLog: appendLog,
      setLogReply: setLogReply,
      unreadCount: unreadCount,
      markAllRead: markAllRead,
      classifySubmitError: classifySubmitError,
      copyFor: copyFor,
      widgetHtml: widgetHtml,
    };
  }

  if (typeof document === 'undefined') return; // not a browser — done.

  // ---- browser storage helpers ----
  function readJSON(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }
  function writeJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function getPending() { return readJSON(K_PENDING) || []; }
  function setPending(ids) { writeJSON(K_PENDING, ids); }

  // ---- DOM ----
  function init() {
    var root = document.getElementById('cr-root');
    if (!root) return;
    var character = root.getAttribute('data-character') || '';

    var sheetsOff = root.dataset.sheets === 'off';
    var copy = copyFor(sheetsOff);

    root.innerHTML = widgetHtml(copy);

    var toggle = root.querySelector('.cr-toggle');
    var panel = root.querySelector('.cr-panel');
    var codeInput = root.querySelector('.cr-code');
    var textInput = root.querySelector('.cr-text');
    var send = root.querySelector('.cr-send');
    var msg = root.querySelector('.cr-msg');

    // ---- chat log ----
    function getLog() { return readJSON(K_LOG) || []; }
    function setLog(l) { writeJSON(K_LOG, l); }
    var logBtn = root.querySelector('.cr-log-btn');

    // History renders in a modal appended to <body>. The modal behaviour is
    // system-agnostic; the parchment skin is gated to CoC via the `.coc` class.
    var backdrop = document.createElement('div');
    backdrop.className = 'cr-modal-backdrop';
    if (document.querySelector('.coc-sheet-root')) backdrop.classList.add('coc');
    backdrop.hidden = true;
    backdrop.innerHTML =
      '<div class="cr-modal" role="dialog" aria-modal="true" aria-label="Correspondence history">' +
        '<div class="cr-modal-head">' +
          '<span class="cr-modal-title">Correspondence — this device</span>' +
          '<button type="button" class="cr-modal-close" aria-label="Close">✕</button>' +
        '</div>' +
        '<div class="cr-modal-body"></div>' +
      '</div>';
    document.body.appendChild(backdrop);
    var logPanel = backdrop.querySelector('.cr-modal-body');
    var closeBtn = backdrop.querySelector('.cr-modal-close');

    var KIND_CLASSES = { applied: 1, rejected: 1, advice: 1 };
    function renderLog() {
      var l = getLog();
      if (!l.length) { logPanel.innerHTML = '<p class="cr-empty">No messages yet.</p>'; return; }
      logPanel.innerHTML = l.slice().reverse().map(function (e) {
        var kindCls = KIND_CLASSES[e.kind] ? ' cr-' + e.kind : '';
        var reply = e.reply
          ? '<div class="cr-reply' + kindCls + '">' + escapeHtml(e.reply) + '</div>'
          : '<div class="cr-reply cr-waiting">…</div>';
        return '<div class="cr-logentry"><div class="cr-you">' + escapeHtml(e.message) + '</div>' + reply + '</div>';
      }).join('');
    }
    function escapeHtml(s) {
      return String(s).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    }
    renderLog();

    // Unread badge on the History button. An `advice`/`rejected` reply does not
    // reload the page the way `applied` does, so without a passive signal a player
    // with a collapsed widget never learns an answer arrived.
    var badge = document.createElement('span');
    badge.className = 'cr-unread';
    badge.setAttribute('aria-live', 'polite');
    badge.style.cssText = 'display:none;margin-left:.4em;min-width:1.35em;padding:0 .35em;' +
      'border-radius:1em;background:#c0392b;color:#fff;font-size:.8em;font-weight:700;' +
      'line-height:1.35em;text-align:center;';
    logBtn.appendChild(badge);

    var baseTitle = document.title;
    function renderBadge() {
      var n = unreadCount(getLog());
      badge.textContent = n ? String(n) : '';
      badge.style.display = n ? 'inline-block' : 'none';
      logBtn.setAttribute('aria-label', n ? 'Open chat history, ' + n + ' unread' : 'Open chat history');
      document.title = n ? '(' + n + ') ' + baseTitle : baseTitle;
    }
    renderBadge();

    function openModal() {
      backdrop.hidden = false;
      document.body.style.overflow = 'hidden';
      logBtn.setAttribute('aria-expanded', 'true');
      setLog(markAllRead(getLog()));  // opening the log is what marks replies seen
      renderLog();
      renderBadge();
      closeBtn.focus();               // move focus into the dialog for keyboard/SR users
    }
    function closeModal() {
      backdrop.hidden = true;
      document.body.style.overflow = '';
      logBtn.setAttribute('aria-expanded', 'false');
      logBtn.focus();                 // restore focus to the trigger
    }
    logBtn.addEventListener('click', openModal);
    closeBtn.addEventListener('click', closeModal);
    backdrop.addEventListener('click', function (e) { if (e.target === backdrop) closeModal(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !backdrop.hidden) closeModal();
    });

    // Persisted "your change is live" flag from before a reload.
    if (localStorage.getItem(K_LIVE) === '1') {
      localStorage.removeItem(K_LIVE);
      msg.textContent = copy.live;
      panel.hidden = false;
      toggle.setAttribute('aria-expanded', 'true');
      codeInput.hidden = !shouldPromptForCode(readJSON(K_CODE), Date.now());
    }

    // Strip the cache-busting param left over from the forced reload above.
    if (location.search.indexOf('_cr=') !== -1 && window.history && history.replaceState) {
      var cleanUrl = new URL(location.href);
      cleanUrl.searchParams.delete('_cr');
      history.replaceState(null, '', cleanUrl.pathname + (cleanUrl.search || '') + cleanUrl.hash);
    }

    toggle.addEventListener('click', function () {
      var open = panel.hidden;
      panel.hidden = !open;
      toggle.setAttribute('aria-expanded', String(open));
      if (open) codeInput.hidden = !shouldPromptForCode(readJSON(K_CODE), Date.now());
    });

    send.addEventListener('click', function () {
      var text = (textInput.value || '').trim();
      if (!text) { msg.textContent = copy.empty; return; }
      var stored = readJSON(K_CODE);
      var code = codeInput.hidden ? (stored && stored.code) : (codeInput.value || '').trim();
      msg.textContent = 'Sending…';

      fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ code: code, character: character, text: text }),
      }).then(function (res) {
        if (res.ok) return res.json().then(function (out) {
          writeJSON(K_CODE, { code: code, at: Date.now() });   // refresh 72h window
          var ids = getPending(); ids.push(out.id); setPending(ids);
          setLog(appendLog(getLog(), { id: out.id, ts: Date.now(), message: text }));
          renderLog();
          textInput.value = '';
          msg.textContent = copy.received;
          startPolling();
        });
        var kind = classifySubmitError(res.status);
        if (kind === 'code') {
          localStorage.removeItem(K_CODE);
          codeInput.hidden = false; codeInput.value = '';
          msg.textContent = 'Code expired — enter the new one.';
        } else if (kind === 'rate') {
          msg.textContent = 'Too many requests — wait a moment.';
        } else {
          msg.textContent = "Couldn't submit — check with your GM.";
        }
      }).catch(function () { msg.textContent = 'Network error — try again.'; });
    });

    var timer = null;
    function startPolling() {
      if (timer || !getPending().length) return;
      timer = setInterval(poll, POLL_MS);
    }
    function poll() {
      var ids = getPending();
      if (!ids.length) { clearInterval(timer); timer = null; return; }
      fetch(ENDPOINT + '?ids=' + encodeURIComponent(ids.join(','))).then(function (res) {
        return res.json();
      }).then(function (results) {
        var done = resolvedResults(results, ids);
        var stale = staleIds(results, ids);
        var gone = goneIds(results, ids);
        if (!done.length && !stale.length && !gone.length) return; // still waiting
        // record replies into the log and drop resolved + handled + gone ids from pending.
        // A gone id gets an 'expired' reply so it surfaces exactly like an answer would.
        var log = getLog();
        var removeIds = {};
        done.forEach(function (d) { removeIds[d.id] = true; log = setLogReply(log, d.id, d.response, d.kind); });
        stale.forEach(function (id) { removeIds[id] = true; });
        gone.forEach(function (id) {
          removeIds[id] = true;
          log = setLogReply(log, id, GONE_TEXT, 'expired');
          done.push({ id: id, response: GONE_TEXT, kind: 'expired' });
        });
        setLog(log);
        setPending(ids.filter(function (id) { return !removeIds[id]; }));
        renderLog();
        // With sheets off there is no sheet to refresh: an `applied` reply is shown like any other.
        if (needsReload(done) && !sheetsOff) {
          localStorage.setItem(K_LIVE, '1');
          // Cache-bust: a plain reload() can be served from bfcache on mobile,
          // showing the "live" banner over stale content. A unique URL forces
          // a fresh document fetch.
          var u = new URL(location.href);
          u.searchParams.set('_cr', String(Date.now()));
          location.replace(u.href);
        } else {
          // advice / rejected only — no reload, so surface it three ways: badge on the
          // History button, the widget expanded with the reply inline, and a title marker.
          // Any one of them survives a player who submitted and looked away.
          renderBadge();
          if (done.length) {
            var newest = done[done.length - 1].response || '';
            msg.textContent = newest.length > 240 ? newest.slice(0, 237) + '… (full reply in 💬 History)' : newest;
            panel.hidden = false;
            toggle.setAttribute('aria-expanded', 'true');
            codeInput.hidden = !shouldPromptForCode(readJSON(K_CODE), Date.now());
          }
          if (!getPending().length) { clearInterval(timer); timer = null; }
        }
      }).catch(function () { /* transient; try again next tick */ });
    }

    // Backgrounded mobile tabs throttle the 15s poll timer; poll immediately
    // when the tab regains focus so a returning player doesn't have to wait.
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden && getPending().length) poll();
    });

    if (getPending().length) startPolling();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
